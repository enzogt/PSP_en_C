#ifndef MIHORA_H
#define MIHORA_H
	void imprimir_hora();
#endif
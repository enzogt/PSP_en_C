# psp_system_y_execl
Pruebas con los procesos. Ahora en Linux Mint
